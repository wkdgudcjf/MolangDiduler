package MainUI;
import javax.swing.*;

public class ViewScheduleUI extends  JFrame {

    private  JButton cancelButton;
    private  JButton checkButton;
    private  JButton deleteButton;
    private  JLabel endLabel;
    private  JScrollPane jScrollPane1;
    private  JLabel scheduleImage;
    private  JPanel schedulePanel;
    private  JTextPane scheduleTextPane;
    private  JLabel startLabel;
    private  JLabel termLabel;
    private  JLabel termLabel2;
    private  JLabel timeLabel;
    private  JButton updateButton;
    private  JLabel writtenTimeLaber;
    
   
    public ViewScheduleUI() {
        initComponents();
    }
    private void initComponents() {
    	setLocation(500,200);
        schedulePanel = new  JPanel();
        termLabel = new  JLabel();
        termLabel2 = new  JLabel();
        timeLabel = new  JLabel();
        startLabel = new  JLabel();
        endLabel = new  JLabel();
        writtenTimeLaber = new  JLabel();
        checkButton = new  JButton();
        updateButton = new  JButton();
        deleteButton = new  JButton();
        cancelButton = new  JButton();
        jScrollPane1 = new  JScrollPane();
        scheduleTextPane = new  JTextPane();
        scheduleImage = new  JLabel();

        setDefaultCloseOperation( WindowConstants.EXIT_ON_CLOSE);
        setTitle("��������/ ���� ��¥");
        setPreferredSize(new java.awt.Dimension(400, 450));

        schedulePanel.setBackground(new java.awt.Color(255, 255, 255));
        schedulePanel.setPreferredSize(new java.awt.Dimension(400, 450));

        termLabel.setFont(new java.awt.Font("���ʷҵ���", 0, 12)); // NOI18N
        termLabel.setText("�� �� ");

        termLabel2.setFont(new java.awt.Font("���ʷҵ���", 0, 12)); // NOI18N
        termLabel2.setText("~");

        timeLabel.setFont(new java.awt.Font("���ʷҵ���", 0, 12)); // NOI18N
        timeLabel.setText("�� �� ");

        startLabel.setFont(new java.awt.Font("���ʷҵ���", 0, 12)); // NOI18N
        startLabel.setText("�������۱Ⱓ");

        endLabel.setFont(new java.awt.Font("���ʷҵ���", 0, 12)); // NOI18N
        endLabel.setText("�������Ⱓ");

        writtenTimeLaber.setFont(new java.awt.Font("���ʷҵ���", 0, 12)); // NOI18N
        writtenTimeLaber.setText("�����ð�");

        checkButton.setFont(new java.awt.Font("���ʷҵ���", 0, 12)); // NOI18N
        checkButton.setText("Ȯ   ��");
        checkButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
           
            }
        });

        updateButton.setFont(new java.awt.Font("���ʷҵ���", 0, 12)); // NOI18N
        updateButton.setText("��  ��");
        updateButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
           
            }
        });

        deleteButton.setFont(new java.awt.Font("���ʷҵ���", 0, 12)); // NOI18N
        deleteButton.setText("��  ��");
        deleteButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
           
            }
        });

        cancelButton.setFont(new java.awt.Font("���ʷҵ���", 0, 12)); // NOI18N
        cancelButton.setText("��  ��");
        cancelButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
           
            }
        });

        scheduleTextPane.setEditable(false);
        scheduleTextPane.setFont(new java.awt.Font("���ʷҵ���", 0, 12)); // NOI18N
        jScrollPane1.setViewportView(scheduleTextPane);

        scheduleImage.setIcon(new  ImageIcon("�׸�8.png")); // NOI18N

         GroupLayout schedulePanelLayout = new  GroupLayout(schedulePanel);
        schedulePanel.setLayout(schedulePanelLayout);
        schedulePanelLayout.setHorizontalGroup(
            schedulePanelLayout.createParallelGroup( GroupLayout.Alignment.LEADING)
            .addGroup(schedulePanelLayout.createSequentialGroup()
                .addGroup(schedulePanelLayout.createParallelGroup( GroupLayout.Alignment.LEADING)
                    .addGroup(schedulePanelLayout.createSequentialGroup()
                        .addGap(7, 7, 7)
                        .addGroup(schedulePanelLayout.createParallelGroup( GroupLayout.Alignment.LEADING, false)
                            .addComponent(timeLabel,  GroupLayout.DEFAULT_SIZE,  GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(termLabel,  GroupLayout.DEFAULT_SIZE,  GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap( LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(schedulePanelLayout.createParallelGroup( GroupLayout.Alignment.LEADING)
                            .addGroup(schedulePanelLayout.createSequentialGroup()
                                .addComponent(startLabel,  GroupLayout.PREFERRED_SIZE, 128,  GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap( LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(termLabel2,  GroupLayout.PREFERRED_SIZE, 16,  GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap( LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(endLabel,  GroupLayout.PREFERRED_SIZE, 156,  GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addGroup(schedulePanelLayout.createSequentialGroup()
                                .addComponent(writtenTimeLaber,  GroupLayout.PREFERRED_SIZE, 73,  GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap( LayoutStyle.ComponentPlacement.RELATED,  GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(scheduleImage))))
                    .addGroup(schedulePanelLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane1,  GroupLayout.PREFERRED_SIZE, 374,  GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 13, Short.MAX_VALUE))
                    .addGroup( GroupLayout.Alignment.TRAILING, schedulePanelLayout.createSequentialGroup()
                        .addContainerGap( GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(checkButton,  GroupLayout.PREFERRED_SIZE, 75,  GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap( LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(updateButton,  GroupLayout.PREFERRED_SIZE, 73,  GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(deleteButton,  GroupLayout.PREFERRED_SIZE, 73,  GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(cancelButton,  GroupLayout.PREFERRED_SIZE, 75,  GroupLayout.PREFERRED_SIZE)
                        .addGap(15, 15, 15)))
                .addContainerGap())
        );
        schedulePanelLayout.setVerticalGroup(
            schedulePanelLayout.createParallelGroup( GroupLayout.Alignment.LEADING)
            .addGroup(schedulePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(schedulePanelLayout.createParallelGroup( GroupLayout.Alignment.BASELINE)
                    .addComponent(termLabel,  GroupLayout.PREFERRED_SIZE, 23,  GroupLayout.PREFERRED_SIZE)
                    .addComponent(termLabel2)
                    .addComponent(startLabel)
                    .addComponent(endLabel))
                .addPreferredGap( LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(schedulePanelLayout.createParallelGroup( GroupLayout.Alignment.LEADING)
                    .addGroup(schedulePanelLayout.createParallelGroup( GroupLayout.Alignment.BASELINE)
                        .addComponent(timeLabel)
                        .addComponent(writtenTimeLaber))
                    .addComponent(scheduleImage))
                .addPreferredGap( LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1,  GroupLayout.DEFAULT_SIZE, 279, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addGroup(schedulePanelLayout.createParallelGroup( GroupLayout.Alignment.BASELINE)
                    .addComponent(checkButton)
                    .addComponent(updateButton)
                    .addComponent(cancelButton)
                    .addComponent(deleteButton))
                .addGap(33, 33, 33))
        );

         GroupLayout layout = new  GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup( GroupLayout.Alignment.LEADING)
            .addComponent(schedulePanel,  GroupLayout.DEFAULT_SIZE, 411, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup( GroupLayout.Alignment.LEADING)
            .addComponent(schedulePanel,  GroupLayout.DEFAULT_SIZE, 440, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>

    public static void main(String args[]) {
      
        try {
            for ( UIManager.LookAndFeelInfo info :  UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                     UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ViewScheduleUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ViewScheduleUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ViewScheduleUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch ( UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ViewScheduleUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ViewScheduleUI().setVisible(true);
            }
        });
    }
 
}
