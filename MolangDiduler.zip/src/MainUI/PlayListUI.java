package MainUI;
import javax.swing.*;
import javax.swing.table.*;

public class PlayListUI extends  JFrame {
    private  JButton addButton;
    private  JButton deleteButton;
    private  JLabel jLabel1;
    private  JScrollPane jspPlayListUI;
    private  JPanel panel1;
    private  JTable PlayListUITable;
    
    public PlayListUI() {
        initComponents();
    }

    private void initComponents() {
    	setLocation(500,200);
        panel1 = new  JPanel();
        jspPlayListUI = new  JScrollPane();
        PlayListUITable = new  JTable();
        addButton = new  JButton();
        deleteButton = new  JButton();
        jLabel1 = new  JLabel();

        setDefaultCloseOperation( WindowConstants.EXIT_ON_CLOSE);
        setTitle("Play List");
        setBackground(new java.awt.Color(255, 255, 255));
        setResizable(false);

        panel1.setBackground(new java.awt.Color(255, 255, 255));
        panel1.setPreferredSize(new java.awt.Dimension(350, 300));

        jspPlayListUI.setPreferredSize(new java.awt.Dimension(350, 275));

        PlayListUITable.setBorder( BorderFactory.createEtchedBorder());
        PlayListUITable.setFont(new java.awt.Font("���ʷҵ���", 0, 12)); // NOI18N
        PlayListUITable.setModel(new  DefaultTableModel(
            new Object [][] {
                {null},
                {null},
                {null},
                {null},
                {null},
                {null},
                {null},
                {null},
                {null},
                {null}
            },
            new String [] {
                "�뷡����"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        PlayListUITable.setCellSelectionEnabled(true);
        PlayListUITable.getTableHeader().setResizingAllowed(false);
        PlayListUITable.getTableHeader().setReorderingAllowed(false);
        jspPlayListUI.setViewportView(PlayListUITable);

        addButton.setFont(new java.awt.Font("���ʷҵ���", 0, 12)); // NOI18N
        addButton.setText("�߰�");
        addButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                
            }
        });

        deleteButton.setFont(new java.awt.Font("���ʷҵ���", 0, 12)); // NOI18N
        deleteButton.setText("����");

        jLabel1.setIcon(new  ImageIcon("mo3.png")); // NOI18N

         GroupLayout panel1Layout = new  GroupLayout(panel1);
        panel1.setLayout(panel1Layout);
        panel1Layout.setHorizontalGroup(
            panel1Layout.createParallelGroup( GroupLayout.Alignment.LEADING)
            .addGroup(panel1Layout.createSequentialGroup()
                .addGroup(panel1Layout.createParallelGroup( GroupLayout.Alignment.LEADING)
                    .addGroup(panel1Layout.createSequentialGroup()
                        .addGap(44, 44, 44)
                        .addComponent(jLabel1)
                        .addPreferredGap( LayoutStyle.ComponentPlacement.RELATED, 35, Short.MAX_VALUE)
                        .addComponent(addButton)
                        .addPreferredGap( LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(deleteButton))
                    .addGroup(panel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jspPlayListUI,  GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        panel1Layout.setVerticalGroup(
            panel1Layout.createParallelGroup( GroupLayout.Alignment.LEADING)
            .addGroup(panel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jspPlayListUI,  GroupLayout.PREFERRED_SIZE, 188,  GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(panel1Layout.createParallelGroup( GroupLayout.Alignment.LEADING)
                    .addGroup(panel1Layout.createParallelGroup( GroupLayout.Alignment.BASELINE)
                        .addComponent(deleteButton)
                        .addComponent(addButton))
                    .addComponent(jLabel1))
                .addContainerGap( GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

         GroupLayout layout = new  GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup( GroupLayout.Alignment.LEADING)
            .addComponent(panel1,  GroupLayout.DEFAULT_SIZE,  GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup( GroupLayout.Alignment.LEADING)
            .addComponent(panel1,  GroupLayout.DEFAULT_SIZE, 324, Short.MAX_VALUE)
        );

        pack();
    }

    public static void main(String args[]) {
     
         new PlayListUI().setVisible(true);
        
    }
    

    
}
