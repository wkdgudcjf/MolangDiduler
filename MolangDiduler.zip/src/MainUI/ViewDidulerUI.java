package MainUI;
import  javax.swing.*;
import javax.swing.table.*;
public class ViewDidulerUI extends  JFrame {
    
    private  JRadioButton allRadioButton;
    private  JButton cancelButton;
    private  JButton deleteButton;
    private  JCheckBox diaryCheckBox;
    private  JComboBox endDay;
    private  JComboBox endMonth;
    private  JComboBox endYear;
    private  JLabel jLabel2;
    private  JTable jTable;
    private  JLabel jlDay1;
    private  JLabel jlDay2;
    private  JLabel jlMonth1;
    private  JLabel jlMonth2;
    private  JLabel jlSearch;
    private  JLabel jlTarget;
    private  JLabel jlTitlt;
    private  JLabel jlYear1;
    private  JLabel jlYear2;
    private  JScrollPane jspPane;
    private  JButton modifyButton;
    private  JRadioButton monthRadioButton;
    private  JPanel panel1;
    private  JPanel panel2;
    private  JRadioButton periodRadioButton;
    private  JCheckBox scheduleCheckBox;
    private  JButton searchButton;
    private  JTextField searchField;
    private  JComboBox searchObject;
    private  ButtonGroup searchScope;
    private  JComboBox startDay;
    private  JComboBox startMonth;
    private  JComboBox startYear;

    public ViewDidulerUI() {
        initComponents();
    }
    private void initComponents() {

        searchScope = new  ButtonGroup();
        panel1 = new  JPanel();
        jlSearch = new  JLabel();
        allRadioButton = new  JRadioButton();
        monthRadioButton = new  JRadioButton();
        periodRadioButton = new  JRadioButton();
        jlTarget = new  JLabel();
        diaryCheckBox = new  JCheckBox();
        scheduleCheckBox = new  JCheckBox();
        panel2 = new  JPanel();
        startYear = new  JComboBox();
        startMonth = new  JComboBox();
        startDay = new  JComboBox();
        jlTitlt = new  JLabel();
        jlYear1 = new  JLabel();
        jlMonth1 = new  JLabel();
        jlDay1 = new  JLabel();
        endMonth = new  JComboBox();
        jlYear2 = new  JLabel();
        endDay = new  JComboBox();
        jlDay2 = new  JLabel();
        endYear = new  JComboBox();
        jlMonth2 = new  JLabel();
        searchObject = new  JComboBox();
        searchField = new  JTextField();
        searchButton = new  JButton();
        jspPane = new  JScrollPane();
        jTable = new  JTable();
        cancelButton = new  JButton();
        modifyButton = new  JButton();
        deleteButton = new  JButton();
        jLabel2 = new  JLabel();

        setDefaultCloseOperation( WindowConstants.EXIT_ON_CLOSE);
        setTitle("�����췯 ����");
        setPreferredSize(new java.awt.Dimension(500, 480));
        setResizable(false);

        panel1.setBackground(new java.awt.Color(255, 255, 255));
        panel1.setPreferredSize(new java.awt.Dimension(500, 480));
        panel1.setLayout(null);

        jlSearch.setFont(new java.awt.Font("���ʷҵ���", 0, 12)); // NOI18N
        jlSearch.setHorizontalAlignment( SwingConstants.RIGHT);
        jlSearch.setText("�˻����� : ");
        panel1.add(jlSearch);
        jlSearch.setBounds(22, 19, 60, 16);

        searchScope.add(allRadioButton);
        allRadioButton.setFont(new java.awt.Font("���ʷҵ���", 0, 12)); // NOI18N
        allRadioButton.setText("��ü");
        allRadioButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
              
            }
        });
        panel1.add(allRadioButton);
        allRadioButton.setBounds(100, 15, 49, 25);

        searchScope.add(monthRadioButton);
        monthRadioButton.setFont(new java.awt.Font("���ʷҵ���", 0, 12)); // NOI18N
        monthRadioButton.setText("�ֱ��Ѵ�");
        panel1.add(monthRadioButton);
        monthRadioButton.setBounds(167, 15, 73, 25);

        searchScope.add(periodRadioButton);
        periodRadioButton.setFont(new java.awt.Font("���ʷҵ���", 0, 12)); // NOI18N
        periodRadioButton.setText("�Ⱓ����");
        periodRadioButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                
            }
        });
        panel1.add(periodRadioButton);
        periodRadioButton.setBounds(258, 15, 73, 25);

        jlTarget.setFont(new java.awt.Font("���ʷҵ���", 0, 12)); // NOI18N
        jlTarget.setHorizontalAlignment( SwingConstants.RIGHT);
        jlTarget.setText("�˻���� : ");
        panel1.add(jlTarget);
        jlTarget.setBounds(22, 62, 60, 16);

        diaryCheckBox.setFont(new java.awt.Font("���ʷҵ���", 0, 12)); // NOI18N
        diaryCheckBox.setText("�ϱ�");
        panel1.add(diaryCheckBox);
        diaryCheckBox.setBounds(100, 58, 49, 25);

        scheduleCheckBox.setFont(new java.awt.Font("���ʷҵ���", 0, 12)); // NOI18N
        scheduleCheckBox.setText("����");
        panel1.add(scheduleCheckBox);
        scheduleCheckBox.setBounds(167, 58, 49, 25);

        panel2.setBackground(new java.awt.Color(255, 255, 255));
        panel2.setPreferredSize(new java.awt.Dimension(440, 42));

        startYear.setModel(new  DefaultComboBoxModel(new String[] { "2010", "2011", "2012", "2013" }));

        startMonth.setModel(new  DefaultComboBoxModel(new String[] { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12" }));

        startDay.setModel(new  DefaultComboBoxModel(new String[] { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10" }));

        jlTitlt.setFont(new java.awt.Font("���ʷҵ���", 0, 12)); // NOI18N
        jlTitlt.setText("~");

        jlYear1.setFont(new java.awt.Font("���ʷҵ���", 0, 12)); // NOI18N
        jlYear1.setText("��");

        jlMonth1.setFont(new java.awt.Font("���ʷҵ���", 0, 12)); // NOI18N
        jlMonth1.setText("��");

        jlDay1.setFont(new java.awt.Font("���ʷҵ���", 0, 12)); // NOI18N
        jlDay1.setText("��");

        endMonth.setModel(new  DefaultComboBoxModel(new String[] { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12" }));

        jlYear2.setFont(new java.awt.Font("���ʷҵ���", 0, 12)); // NOI18N
        jlYear2.setText("��");

        endDay.setModel(new  DefaultComboBoxModel(new String[] { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10" }));

        jlDay2.setFont(new java.awt.Font("���ʷҵ���", 0, 12)); // NOI18N
        jlDay2.setText("��");

        endYear.setModel(new  DefaultComboBoxModel(new String[] { "2010", "2011", "2012", "2013" }));

        jlMonth2.setFont(new java.awt.Font("���ʷҵ���", 0, 12)); // NOI18N
        jlMonth2.setText("��");

         GroupLayout panel2Layout = new  GroupLayout(panel2);
        panel2.setLayout(panel2Layout);
        panel2Layout.setHorizontalGroup(
            panel2Layout.createParallelGroup( GroupLayout.Alignment.LEADING)
            .addGroup(panel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(startYear,  GroupLayout.PREFERRED_SIZE, 66,  GroupLayout.PREFERRED_SIZE)
                .addPreferredGap( LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jlYear1)
                .addPreferredGap( LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(startMonth,  GroupLayout.PREFERRED_SIZE, 46,  GroupLayout.PREFERRED_SIZE)
                .addPreferredGap( LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jlMonth1)
                .addPreferredGap( LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(startDay,  GroupLayout.PREFERRED_SIZE,  GroupLayout.DEFAULT_SIZE,  GroupLayout.PREFERRED_SIZE)
                .addPreferredGap( LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jlDay1)
                .addPreferredGap( LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jlTitlt)
                .addPreferredGap( LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(endYear,  GroupLayout.PREFERRED_SIZE, 66,  GroupLayout.PREFERRED_SIZE)
                .addPreferredGap( LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jlYear2)
                .addPreferredGap( LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(endMonth,  GroupLayout.PREFERRED_SIZE, 46,  GroupLayout.PREFERRED_SIZE)
                .addPreferredGap( LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jlMonth2)
                .addPreferredGap( LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(endDay,  GroupLayout.PREFERRED_SIZE,  GroupLayout.DEFAULT_SIZE,  GroupLayout.PREFERRED_SIZE)
                .addPreferredGap( LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jlDay2)
                .addContainerGap(47, Short.MAX_VALUE))
        );
        panel2Layout.setVerticalGroup(
            panel2Layout.createParallelGroup( GroupLayout.Alignment.LEADING)
            .addGroup(panel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panel2Layout.createParallelGroup( GroupLayout.Alignment.LEADING)
                    .addGroup(panel2Layout.createParallelGroup( GroupLayout.Alignment.BASELINE)
                        .addComponent(endYear,  GroupLayout.PREFERRED_SIZE,  GroupLayout.DEFAULT_SIZE,  GroupLayout.PREFERRED_SIZE)
                        .addComponent(endMonth,  GroupLayout.PREFERRED_SIZE,  GroupLayout.DEFAULT_SIZE,  GroupLayout.PREFERRED_SIZE)
                        .addComponent(endDay,  GroupLayout.PREFERRED_SIZE,  GroupLayout.DEFAULT_SIZE,  GroupLayout.PREFERRED_SIZE)
                        .addComponent(jlYear2)
                        .addComponent(jlMonth2)
                        .addComponent(jlDay2))
                    .addGroup(panel2Layout.createParallelGroup( GroupLayout.Alignment.BASELINE)
                        .addComponent(startYear,  GroupLayout.PREFERRED_SIZE,  GroupLayout.DEFAULT_SIZE,  GroupLayout.PREFERRED_SIZE)
                        .addComponent(startMonth,  GroupLayout.PREFERRED_SIZE,  GroupLayout.DEFAULT_SIZE,  GroupLayout.PREFERRED_SIZE)
                        .addComponent(startDay,  GroupLayout.PREFERRED_SIZE,  GroupLayout.DEFAULT_SIZE,  GroupLayout.PREFERRED_SIZE)
                        .addComponent(jlTitlt)
                        .addComponent(jlYear1)
                        .addComponent(jlMonth1)
                        .addComponent(jlDay1)))
                .addContainerGap(11, Short.MAX_VALUE))
        );

        panel1.add(panel2);
        panel2.setBounds(0, 93, 500, 42);

        searchObject.setFont(new java.awt.Font("���ʷҵ���", 0, 12)); // NOI18N
        searchObject.setModel(new  DefaultComboBoxModel(new String[] { "����", "����+����" }));
        panel1.add(searchObject);
        searchObject.setBounds(22, 142, 88, 22);
        panel1.add(searchField);
        searchField.setBounds(117, 143, 285, 21);

        searchButton.setFont(new java.awt.Font("���ʷҵ���", 0, 12)); // NOI18N
        searchButton.setText("�˻�");
        panel1.add(searchButton);
        searchButton.setBounds(409, 141, 57, 25);

        jspPane.setPreferredSize(new java.awt.Dimension(455, 400));

        jTable.setFont(new java.awt.Font("���ʷҵ���", 0, 12)); // NOI18N
        jTable.setModel(new  DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "����", "�ۼ���¥", "��������"
            }
        ));
        jspPane.setViewportView(jTable);

        panel1.add(jspPane);
        jspPane.setBounds(22, 176, 440, 203);

        cancelButton.setFont(new java.awt.Font("���ʷҵ���", 0, 12)); // NOI18N
        cancelButton.setText("���");
        panel1.add(cancelButton);
        cancelButton.setBounds(405, 397, 57, 25);

        modifyButton.setFont(new java.awt.Font("���ʷҵ���", 0, 12)); // NOI18N
        modifyButton.setText("����");
        panel1.add(modifyButton);
        modifyButton.setBounds(330, 397, 57, 25);

        deleteButton.setFont(new java.awt.Font("���ʷҵ���", 0, 12)); // NOI18N
        deleteButton.setText("����");
        panel1.add(deleteButton);
        deleteButton.setBounds(255, 397, 57, 25);

        jLabel2.setIcon(new  ImageIcon("mo2.png")); // NOI18N
        panel1.add(jLabel2);
        jLabel2.setBounds(350, 10, 56, 73);

         GroupLayout layout = new  GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup( GroupLayout.Alignment.LEADING)
            .addGroup( GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(panel1,  GroupLayout.PREFERRED_SIZE,  GroupLayout.DEFAULT_SIZE,  GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup( GroupLayout.Alignment.LEADING)
            .addGroup( GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(panel1,  GroupLayout.PREFERRED_SIZE,  GroupLayout.DEFAULT_SIZE,  GroupLayout.PREFERRED_SIZE)
                .addGap(0, 20, Short.MAX_VALUE))
        );
        setLocation(500,200);
        pack();
    }

    public static void main(String args[]) {
       
        try {
            for ( UIManager.LookAndFeelInfo info :  UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                     UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ViewDidulerUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ViewDidulerUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ViewDidulerUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch ( UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ViewDidulerUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ViewDidulerUI().setVisible(true);
            }
        });
    }

    
}
