package MainUI;
import javax.swing.*;
import javax.swing.border.*;
public class ViewDiaryUI extends  JFrame {
	
    private  JButton cancelButton;
    private  JButton checkButton;
    private  JTextPane diaryContent;
    private  JLabel diaryImage;
    private  JPanel diaryPanel;
    private  JButton image;
    private  JPanel imagePanel;
    private  JScrollPane jScrollPane1;
    private  JButton removeButton;
    private  JButton updateButton;
    
    public ViewDiaryUI() {
        initComponents();
    }

    private void initComponents() {
    	setLocation(400,300);
        diaryPanel = new  JPanel();
        imagePanel = new  JPanel();
        diaryImage = new  JLabel();
        image = new  JButton();
        jScrollPane1 = new  JScrollPane();
        diaryContent = new  JTextPane();
        checkButton = new  JButton();
        updateButton = new  JButton();
        cancelButton = new  JButton();
        removeButton = new  JButton();

        setDefaultCloseOperation( WindowConstants.EXIT_ON_CLOSE);
        setTitle("���̾��/ �ۼ� ��¥");
        setPreferredSize(new java.awt.Dimension(400, 630));

        diaryPanel.setBackground(new java.awt.Color(255, 255, 255));
        diaryPanel.setPreferredSize(new java.awt.Dimension(400, 630));

        imagePanel.setBackground(new java.awt.Color(247, 231, 195));
        imagePanel.setBorder(new  SoftBevelBorder(BevelBorder.RAISED));
        imagePanel.setPreferredSize(new java.awt.Dimension(372, 361));

        diaryImage.setIcon(new  ImageIcon("�׸�7.png")); // NOI18N
        diaryImage.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                diaryImageMouseClicked(evt);
            }
        });

        image.setFont(new java.awt.Font("���ʷҵ���", 0, 12)); // NOI18N
        image.setText("�̹�������");
        image.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                imageActionPerformed(evt);
            }
        });

         GroupLayout imagePanelLayout = new  GroupLayout(imagePanel);
        imagePanel.setLayout(imagePanelLayout);
        imagePanelLayout.setHorizontalGroup(
            imagePanelLayout.createParallelGroup( GroupLayout.Alignment.LEADING)
            .addComponent(image,  GroupLayout.Alignment.TRAILING,  GroupLayout.DEFAULT_SIZE,  GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(imagePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(diaryImage)
                .addContainerGap(297, Short.MAX_VALUE))
        );
        imagePanelLayout.setVerticalGroup(
            imagePanelLayout.createParallelGroup( GroupLayout.Alignment.LEADING)
            .addGroup(imagePanelLayout.createSequentialGroup()
                .addComponent(diaryImage)
                .addPreferredGap( LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(image,  GroupLayout.DEFAULT_SIZE, 214, Short.MAX_VALUE))
        );

        image.getAccessibleContext().setAccessibleName("�̹��� ���� ");

        diaryContent.setEditable(false);
        jScrollPane1.setViewportView(diaryContent);

        checkButton.setFont(new java.awt.Font("���ʷҵ���", 0, 12)); // NOI18N
        checkButton.setText("Ȯ   ��");
        checkButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                checkButtonActionPerformed(evt);
            }
        });

        updateButton.setFont(new java.awt.Font("���ʷҵ���", 0, 12)); // NOI18N
        updateButton.setText("��  ��");
        updateButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateButtonActionPerformed(evt);
            }
        });

        cancelButton.setFont(new java.awt.Font("���ʷҵ���", 0, 12)); // NOI18N
        cancelButton.setText("��  ��");
        cancelButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancelButtonActionPerformed(evt);
            }
        });

        removeButton.setFont(new java.awt.Font("���ʷҵ���", 0, 12)); // NOI18N
        removeButton.setText("��  ��");
        removeButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                removeButtonActionPerformed(evt);
            }
        });

         GroupLayout diaryPanelLayout = new  GroupLayout(diaryPanel);
        diaryPanel.setLayout(diaryPanelLayout);
        diaryPanelLayout.setHorizontalGroup(
            diaryPanelLayout.createParallelGroup( GroupLayout.Alignment.LEADING)
            .addGroup(diaryPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(diaryPanelLayout.createParallelGroup( GroupLayout.Alignment.LEADING)
                    .addComponent(imagePanel,  GroupLayout.PREFERRED_SIZE,  GroupLayout.DEFAULT_SIZE,  GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane1,  GroupLayout.PREFERRED_SIZE, 372,  GroupLayout.PREFERRED_SIZE))
                .addContainerGap(16, Short.MAX_VALUE))
            .addGroup( GroupLayout.Alignment.TRAILING, diaryPanelLayout.createSequentialGroup()
                .addContainerGap( GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(checkButton,  GroupLayout.PREFERRED_SIZE, 75,  GroupLayout.PREFERRED_SIZE)
                .addPreferredGap( LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(updateButton,  GroupLayout.PREFERRED_SIZE, 73,  GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(removeButton,  GroupLayout.PREFERRED_SIZE, 73,  GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(cancelButton,  GroupLayout.PREFERRED_SIZE, 75,  GroupLayout.PREFERRED_SIZE)
                .addGap(24, 24, 24))
        );
        diaryPanelLayout.setVerticalGroup(
            diaryPanelLayout.createParallelGroup( GroupLayout.Alignment.LEADING)
            .addGroup(diaryPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(imagePanel,  GroupLayout.PREFERRED_SIZE, 273,  GroupLayout.PREFERRED_SIZE)
                .addPreferredGap( LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1,  GroupLayout.PREFERRED_SIZE, 254,  GroupLayout.PREFERRED_SIZE)
                .addPreferredGap( LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(diaryPanelLayout.createParallelGroup( GroupLayout.Alignment.BASELINE)
                    .addComponent(checkButton)
                    .addComponent(updateButton)
                    .addComponent(cancelButton)
                    .addComponent(removeButton))
                .addContainerGap(64, Short.MAX_VALUE))
        );

         GroupLayout layout = new  GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup( GroupLayout.Alignment.LEADING)
            .addComponent(diaryPanel,  GroupLayout.DEFAULT_SIZE,  GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup( GroupLayout.Alignment.LEADING)
            .addComponent(diaryPanel,  GroupLayout.PREFERRED_SIZE, 642,  GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>

    private void checkButtonActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
    }                                           

    private void updateButtonActionPerformed(java.awt.event.ActionEvent evt) {                                             
        // TODO add your handling code here:
    }                                            

    private void cancelButtonActionPerformed(java.awt.event.ActionEvent evt) {                                             
        // TODO add your handling code here:
    }                                            

    private void removeButtonActionPerformed(java.awt.event.ActionEvent evt) {                                             
        // TODO add your handling code here:
    }                                            

    private void imageActionPerformed(java.awt.event.ActionEvent evt) {                                      
        // TODO add your handling code here:
    }                                     

    private void diaryImageMouseClicked(java.awt.event.MouseEvent evt) {                                        
        // TODO add your handling code here:
    }                                       

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for ( UIManager.LookAndFeelInfo info :  UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                     UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ViewDiaryUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ViewDiaryUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ViewDiaryUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch ( UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ViewDiaryUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ViewDiaryUI().setVisible(true);
            }
        });
    }
    
}
