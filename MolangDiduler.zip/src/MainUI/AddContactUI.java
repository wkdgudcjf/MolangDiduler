package MainUI;
import   javax.swing.*;

public class AddContactUI extends  JFrame {
	
	    public AddContactUI() {
	        initComponents();
	    }

	    private void initComponents() {

	        panel1 = new  JPanel();
	        jlName = new  JLabel();
	        nameField = new  JTextField();
	        jlEmail = new  JLabel();
	        emailField1 = new  JTextField();
	        jlPhone = new  JLabel();
	        phoneField1 = new  JTextField();
	        jlBirth = new  JLabel();
	        cancelButton = new  JButton();
	        okButton = new  JButton();
	        monthComboBox = new  JComboBox();
	        dayComboBox = new  JComboBox();
	        jlMonth = new  JLabel();
	        jlDay = new  JLabel();
	        jLabel1 = new  JLabel();
	        emailField2 = new  JTextField();
	        jLabel2 = new  JLabel();
	        phoneField2 = new  JTextField();
	        jLabel3 = new  JLabel();
	        phoneField3 = new  JTextField();
	        jLabel4 = new  JLabel();
	        groupComboBox = new  JComboBox();
	        jLabel5 = new  JLabel();

	        setDefaultCloseOperation( WindowConstants.EXIT_ON_CLOSE);
	        setTitle("�θ� �߰�");
	        setResizable(false);

	        panel1.setBackground(new java.awt.Color(255, 255, 255));
	        panel1.setPreferredSize(new java.awt.Dimension(320, 350));

	        jlName.setFont(new java.awt.Font("���ʷҵ���", 0, 12)); // NOI18N
	        jlName.setHorizontalAlignment( SwingConstants.RIGHT);
	        jlName.setText("�̸� :");

	        jlEmail.setFont(new java.awt.Font("���ʷҵ���", 0, 12)); // NOI18N
	        jlEmail.setHorizontalAlignment( SwingConstants.RIGHT);
	        jlEmail.setText("�̸��� :");

	        jlPhone.setFont(new java.awt.Font("���ʷҵ���", 0, 12)); // NOI18N
	        jlPhone.setHorizontalAlignment( SwingConstants.RIGHT);
	        jlPhone.setText("��ȭ��ȣ :");

	        jlBirth.setFont(new java.awt.Font("���ʷҵ���", 0, 12)); // NOI18N
	        jlBirth.setHorizontalAlignment( SwingConstants.RIGHT);
	        jlBirth.setText("���� :");

	        cancelButton.setFont(new java.awt.Font("���ʷҵ���", 0, 12)); // NOI18N
	        cancelButton.setText("���");

	        okButton.setFont(new java.awt.Font("���ʷҵ���", 0, 12)); // NOI18N
	        okButton.setText("Ȯ��");

	        monthComboBox.setModel(new  DefaultComboBoxModel(new String[] { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12" }));

	        dayComboBox.setModel(new  DefaultComboBoxModel(new String[] { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10" }));

	        jlMonth.setFont(new java.awt.Font("���ʷҵ���", 0, 12)); // NOI18N
	        jlMonth.setText("��");

	        jlDay.setFont(new java.awt.Font("���ʷҵ���", 0, 12)); // NOI18N
	        jlDay.setText("��");

	        jLabel1.setFont(new java.awt.Font("���ʷҵ���", 0, 12)); // NOI18N
	        jLabel1.setText("@");

	        jLabel2.setFont(new java.awt.Font("���ʷҵ���", 0, 12)); // NOI18N
	        jLabel2.setText("-");

	        jLabel3.setFont(new java.awt.Font("���ʷҵ���", 0, 12)); // NOI18N
	        jLabel3.setText("-");

	        jLabel4.setIcon(new  ImageIcon("mo1.png")); // NOI18N

	        groupComboBox.setModel(new  DefaultComboBoxModel(new String[] { "������", "ģ��" }));

	        jLabel5.setFont(new java.awt.Font("���ʷҵ���", 0, 12)); // NOI18N
	        jLabel5.setText("�׷� :");

	         GroupLayout panel1Layout = new  GroupLayout(panel1);
	        panel1.setLayout(panel1Layout);
	        panel1Layout.setHorizontalGroup(
	            panel1Layout.createParallelGroup( GroupLayout.Alignment.LEADING)
	            .addGroup(panel1Layout.createSequentialGroup()
	                .addContainerGap()
	                .addGroup(panel1Layout.createParallelGroup( GroupLayout.Alignment.LEADING)
	                    .addGroup(panel1Layout.createParallelGroup( GroupLayout.Alignment.LEADING)
	                        .addGroup( GroupLayout.Alignment.TRAILING, panel1Layout.createSequentialGroup()
	                            .addComponent(jlName,  GroupLayout.PREFERRED_SIZE, 66,  GroupLayout.PREFERRED_SIZE)
	                            .addPreferredGap( LayoutStyle.ComponentPlacement.RELATED)
	                            .addComponent(nameField,  GroupLayout.PREFERRED_SIZE, 180,  GroupLayout.PREFERRED_SIZE))
	                        .addGroup( GroupLayout.Alignment.TRAILING, panel1Layout.createSequentialGroup()
	                            .addGroup(panel1Layout.createParallelGroup( GroupLayout.Alignment.TRAILING)
	                                .addGroup( GroupLayout.Alignment.LEADING, panel1Layout.createSequentialGroup()
	                                    .addComponent(jlPhone,  GroupLayout.PREFERRED_SIZE, 66,  GroupLayout.PREFERRED_SIZE)
	                                    .addPreferredGap( LayoutStyle.ComponentPlacement.RELATED)
	                                    .addComponent(phoneField1,  GroupLayout.PREFERRED_SIZE, 50,  GroupLayout.PREFERRED_SIZE))
	                                .addGroup(panel1Layout.createSequentialGroup()
	                                    .addComponent(jlEmail,  GroupLayout.PREFERRED_SIZE, 66,  GroupLayout.PREFERRED_SIZE)
	                                    .addPreferredGap( LayoutStyle.ComponentPlacement.RELATED)
	                                    .addComponent(emailField1,  GroupLayout.PREFERRED_SIZE, 50,  GroupLayout.PREFERRED_SIZE)))
	                            .addPreferredGap( LayoutStyle.ComponentPlacement.RELATED)
	                            .addGroup(panel1Layout.createParallelGroup( GroupLayout.Alignment.LEADING, false)
	                                .addGroup(panel1Layout.createSequentialGroup()
	                                    .addComponent(jLabel1)
	                                    .addPreferredGap( LayoutStyle.ComponentPlacement.RELATED)
	                                    .addComponent(emailField2))
	                                .addGroup(panel1Layout.createSequentialGroup()
	                                    .addComponent(jLabel2)
	                                    .addPreferredGap( LayoutStyle.ComponentPlacement.RELATED)
	                                    .addComponent(phoneField2,  GroupLayout.PREFERRED_SIZE, 50,  GroupLayout.PREFERRED_SIZE)
	                                    .addPreferredGap( LayoutStyle.ComponentPlacement.RELATED)
	                                    .addComponent(jLabel3)
	                                    .addPreferredGap( LayoutStyle.ComponentPlacement.RELATED)
	                                    .addComponent(phoneField3,  GroupLayout.PREFERRED_SIZE, 50,  GroupLayout.PREFERRED_SIZE)))))
	                    .addGroup(panel1Layout.createParallelGroup( GroupLayout.Alignment.TRAILING)
	                        .addGroup(panel1Layout.createSequentialGroup()
	                            .addComponent(jLabel5)
	                            .addGap(18, 18, 18)
	                            .addComponent(groupComboBox,  GroupLayout.PREFERRED_SIZE,  GroupLayout.DEFAULT_SIZE,  GroupLayout.PREFERRED_SIZE))
	                        .addGroup(panel1Layout.createSequentialGroup()
	                            .addGroup(panel1Layout.createParallelGroup( GroupLayout.Alignment.LEADING)
	                                .addComponent(jLabel4)
	                                .addComponent(jlBirth,  GroupLayout.Alignment.TRAILING,  GroupLayout.PREFERRED_SIZE, 66,  GroupLayout.PREFERRED_SIZE))
	                            .addGap(18, 18, 18)
	                            .addGroup(panel1Layout.createParallelGroup( GroupLayout.Alignment.LEADING)
	                                .addGroup(panel1Layout.createSequentialGroup()
	                                    .addComponent(monthComboBox,  GroupLayout.PREFERRED_SIZE,  GroupLayout.DEFAULT_SIZE,  GroupLayout.PREFERRED_SIZE)
	                                    .addPreferredGap( LayoutStyle.ComponentPlacement.RELATED)
	                                    .addComponent(jlMonth)
	                                    .addPreferredGap( LayoutStyle.ComponentPlacement.UNRELATED)
	                                    .addComponent(dayComboBox,  GroupLayout.PREFERRED_SIZE,  GroupLayout.DEFAULT_SIZE,  GroupLayout.PREFERRED_SIZE)
	                                    .addPreferredGap( LayoutStyle.ComponentPlacement.RELATED)
	                                    .addComponent(jlDay))
	                                .addGroup(panel1Layout.createSequentialGroup()
	                                    .addComponent(okButton)
	                                    .addPreferredGap( LayoutStyle.ComponentPlacement.RELATED)
	                                    .addComponent(cancelButton)))))))
	        );
	        panel1Layout.setVerticalGroup(
	            panel1Layout.createParallelGroup( GroupLayout.Alignment.LEADING)
	            .addGroup(panel1Layout.createSequentialGroup()
	                .addGap(29, 29, 29)
	                .addGroup(panel1Layout.createParallelGroup( GroupLayout.Alignment.BASELINE)
	                    .addComponent(jlName)
	                    .addComponent(nameField,  GroupLayout.PREFERRED_SIZE,  GroupLayout.DEFAULT_SIZE,  GroupLayout.PREFERRED_SIZE))
	                .addPreferredGap( LayoutStyle.ComponentPlacement.UNRELATED)
	                .addGroup(panel1Layout.createParallelGroup( GroupLayout.Alignment.BASELINE)
	                    .addComponent(jlEmail)
	                    .addComponent(emailField1,  GroupLayout.PREFERRED_SIZE,  GroupLayout.DEFAULT_SIZE,  GroupLayout.PREFERRED_SIZE)
	                    .addComponent(jLabel1)
	                    .addComponent(emailField2,  GroupLayout.PREFERRED_SIZE,  GroupLayout.DEFAULT_SIZE,  GroupLayout.PREFERRED_SIZE))
	                .addPreferredGap( LayoutStyle.ComponentPlacement.UNRELATED)
	                .addGroup(panel1Layout.createParallelGroup( GroupLayout.Alignment.BASELINE)
	                    .addComponent(jlPhone)
	                    .addComponent(phoneField1,  GroupLayout.PREFERRED_SIZE,  GroupLayout.DEFAULT_SIZE,  GroupLayout.PREFERRED_SIZE)
	                    .addComponent(jLabel2)
	                    .addComponent(phoneField2,  GroupLayout.PREFERRED_SIZE,  GroupLayout.DEFAULT_SIZE,  GroupLayout.PREFERRED_SIZE)
	                    .addComponent(jLabel3)
	                    .addComponent(phoneField3,  GroupLayout.PREFERRED_SIZE,  GroupLayout.DEFAULT_SIZE,  GroupLayout.PREFERRED_SIZE))
	                .addPreferredGap( LayoutStyle.ComponentPlacement.UNRELATED)
	                .addGroup(panel1Layout.createParallelGroup( GroupLayout.Alignment.BASELINE)
	                    .addComponent(jlBirth)
	                    .addComponent(monthComboBox,  GroupLayout.PREFERRED_SIZE,  GroupLayout.DEFAULT_SIZE,  GroupLayout.PREFERRED_SIZE)
	                    .addComponent(dayComboBox,  GroupLayout.PREFERRED_SIZE,  GroupLayout.DEFAULT_SIZE,  GroupLayout.PREFERRED_SIZE)
	                    .addComponent(jlMonth)
	                    .addComponent(jlDay))
	                .addGroup(panel1Layout.createParallelGroup( GroupLayout.Alignment.LEADING)
	                    .addGroup(panel1Layout.createSequentialGroup()
	                        .addPreferredGap( LayoutStyle.ComponentPlacement.RELATED, 40, Short.MAX_VALUE)
	                        .addComponent(jLabel4)
	                        .addContainerGap())
	                    .addGroup(panel1Layout.createSequentialGroup()
	                        .addPreferredGap( LayoutStyle.ComponentPlacement.UNRELATED)
	                        .addGroup(panel1Layout.createParallelGroup( GroupLayout.Alignment.BASELINE)
	                            .addComponent(groupComboBox,  GroupLayout.PREFERRED_SIZE,  GroupLayout.DEFAULT_SIZE,  GroupLayout.PREFERRED_SIZE)
	                            .addComponent(jLabel5))
	                        .addGap(55, 55, 55)
	                        .addGroup(panel1Layout.createParallelGroup( GroupLayout.Alignment.BASELINE)
	                            .addComponent(cancelButton)
	                            .addComponent(okButton))
	                        .addContainerGap( GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
	        );

	         GroupLayout layout = new  GroupLayout(getContentPane());
	        getContentPane().setLayout(layout);
	        layout.setHorizontalGroup(
	            layout.createParallelGroup( GroupLayout.Alignment.LEADING)
	            .addComponent(panel1,  GroupLayout.PREFERRED_SIZE,  GroupLayout.DEFAULT_SIZE,  GroupLayout.PREFERRED_SIZE)
	        );
	        layout.setVerticalGroup(
	            layout.createParallelGroup( GroupLayout.Alignment.LEADING)
	            .addComponent(panel1,  GroupLayout.PREFERRED_SIZE,  GroupLayout.DEFAULT_SIZE,  GroupLayout.PREFERRED_SIZE)
	        );

	        pack();
	    }// </editor-fold>

	    /**
	     * @param args the command line arguments
	     */
	    public static void main(String args[]) {
	        /* Set the Nimbus look and feel */
	        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
	        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
	         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
	         */
	        try {
	            for ( UIManager.LookAndFeelInfo info :  UIManager.getInstalledLookAndFeels()) {
	                if ("Nimbus".equals(info.getName())) {
	                     UIManager.setLookAndFeel(info.getClassName());
	                    break;
	                }
	            }
	        } catch (ClassNotFoundException ex) {
	            java.util.logging.Logger.getLogger(AddContactUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
	        } catch (InstantiationException ex) {
	            java.util.logging.Logger.getLogger(AddContactUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
	        } catch (IllegalAccessException ex) {
	            java.util.logging.Logger.getLogger(AddContactUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
	        } catch ( UnsupportedLookAndFeelException ex) {
	            java.util.logging.Logger.getLogger(AddContactUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
	        }
	        //</editor-fold>

	        /* Create and display the form */
	        java.awt.EventQueue.invokeLater(new Runnable() {
	            public void run() {
	                new AddContactUI().setVisible(true);
	            }
	        });
	    }
	    // Variables declaration - do not modify
	    private  JButton cancelButton;
	    private  JComboBox dayComboBox;
	    private  JTextField emailField1;
	    private  JTextField emailField2;
	    private  JComboBox groupComboBox;
	    private  JLabel jLabel1;
	    private  JLabel jLabel2;
	    private  JLabel jLabel3;
	    private  JLabel jLabel4;
	    private  JLabel jLabel5;
	    private  JLabel jlBirth;
	    private  JLabel jlDay;
	    private  JLabel jlEmail;
	    private  JLabel jlMonth;
	    private  JLabel jlName;
	    private  JLabel jlPhone;
	    private  JComboBox monthComboBox;
	    private  JTextField nameField;
	    private  JButton okButton;
	    private  JPanel panel1;
	    private  JTextField phoneField1;
	    private  JTextField phoneField2;
	    private  JTextField phoneField3;
	    // End of variables declaration
	}
