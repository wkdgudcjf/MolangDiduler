package MainUI;
import   javax.swing.*;
import   javax.swing.table.*;
public class ContactManagementUI extends JPanel {
    private  JButton addButton;
    private  JRadioButton birthRadioBox;
    private  JTabbedPane connectionSubPanel;
    private  JPanel defaultTab;
    private  JButton deleteButton;
    private  JRadioButton emailRadioBox;
    private  JPanel friendTab;
    private  JScrollPane jScrollPane1;
    private  JScrollPane jScrollPane2;
    private  JScrollPane jScrollPane3;
    private  JTable jTable1;
    private  JTable jTable2;
    private  JTable jTable3;
    private  JButton modifyButton;
    private  JRadioButton nameRadioBox;
    private  JRadioButton phoneRadioBox;
    private  JButton searchButton;
    private  JTextField searchField;
    private  ButtonGroup searchTarget;
    private  JPanel wholeTab;

	public ContactManagementUI() {
	        initComponents();
	    }
	    private void initComponents() {

	        searchTarget = new  ButtonGroup();
	        connectionSubPanel = new  JTabbedPane();
	        wholeTab = new  JPanel();
	        jScrollPane1 = new  JScrollPane();
	        jTable1 = new  JTable();
	        searchField = new  JTextField();
	        searchButton = new  JButton();
	        nameRadioBox = new  JRadioButton();
	        emailRadioBox = new  JRadioButton();
	        phoneRadioBox = new  JRadioButton();
	        birthRadioBox = new  JRadioButton();
	        defaultTab = new  JPanel();
	        jScrollPane2 = new  JScrollPane();
	        jTable2 = new  JTable();
	        friendTab = new  JPanel();
	        jScrollPane3 = new  JScrollPane();
	        jTable3 = new  JTable();
	        addButton = new  JButton();
	        modifyButton = new  JButton();
	        deleteButton = new  JButton();

	        connectionSubPanel.setBorder( BorderFactory.createTitledBorder(""));
	        connectionSubPanel.setFont(new java.awt.Font("���ʷҵ���", 0, 12)); // NOI18N

	        jTable1.setModel(new  DefaultTableModel(
	            new Object [][] {
	                {null, null, null, null},
	                {null, null, null, null},
	                {null, null, null, null},
	                {null, null, null, null}
	            },
	            new String [] {
	                "�̸�", "�̸���", "��ȭ��ȣ", "����"
	            }
	        ));
	        jScrollPane1.setViewportView(jTable1);

	        searchButton.setText("�˻�");

	        searchTarget.add(nameRadioBox);
	        nameRadioBox.setSelected(true);
	        nameRadioBox.setText("�̸�");

	        searchTarget.add(emailRadioBox);
	        emailRadioBox.setText("�̸���");

	        searchTarget.add(phoneRadioBox);
	        phoneRadioBox.setText("��ȭ��ȣ");

	        searchTarget.add(birthRadioBox);
	        birthRadioBox.setText("����");

	         GroupLayout wholeTabLayout = new  GroupLayout(wholeTab);
	        wholeTab.setLayout(wholeTabLayout);
	        wholeTabLayout.setHorizontalGroup(
	            wholeTabLayout.createParallelGroup( GroupLayout.Alignment.LEADING)
	            .addComponent(jScrollPane1,  GroupLayout.DEFAULT_SIZE, 704, Short.MAX_VALUE)
	            .addGroup(wholeTabLayout.createSequentialGroup()
	                .addGap(178, 178, 178)
	                .addComponent(searchField,  GroupLayout.PREFERRED_SIZE, 129,  GroupLayout.PREFERRED_SIZE)
	                .addGap(18, 18, 18)
	                .addComponent(searchButton)
	                .addGap(26, 26, 26)
	                .addComponent(nameRadioBox)
	                .addPreferredGap( LayoutStyle.ComponentPlacement.RELATED)
	                .addComponent(emailRadioBox)
	                .addPreferredGap( LayoutStyle.ComponentPlacement.RELATED)
	                .addComponent(phoneRadioBox)
	                .addPreferredGap( LayoutStyle.ComponentPlacement.RELATED)
	                .addComponent(birthRadioBox)
	                .addContainerGap())
	        );
	        wholeTabLayout.setVerticalGroup(
	            wholeTabLayout.createParallelGroup( GroupLayout.Alignment.LEADING)
	            .addGroup( GroupLayout.Alignment.TRAILING, wholeTabLayout.createSequentialGroup()
	                .addGap(0, 6, Short.MAX_VALUE)
	                .addGroup(wholeTabLayout.createParallelGroup( GroupLayout.Alignment.BASELINE)
	                    .addComponent(searchField,  GroupLayout.PREFERRED_SIZE, 21,  GroupLayout.PREFERRED_SIZE)
	                    .addComponent(searchButton)
	                    .addComponent(nameRadioBox)
	                    .addComponent(emailRadioBox)
	                    .addComponent(phoneRadioBox)
	                    .addComponent(birthRadioBox))
	                .addPreferredGap( LayoutStyle.ComponentPlacement.UNRELATED)
	                .addComponent(jScrollPane1,  GroupLayout.PREFERRED_SIZE, 279,  GroupLayout.PREFERRED_SIZE))
	        );

	        connectionSubPanel.addTab("��ü", wholeTab);

	        jTable2.setModel(new  DefaultTableModel(
	            new Object [][] {
	                {null, null, null, null},
	                {null, null, null, null},
	                {null, null, null, null},
	                {null, null, null, null}
	            },
	            new String [] {
	                "�̸�", "�̸���", "��ȭ��ȣ", "����"
	            }
	        ));
	        jScrollPane2.setViewportView(jTable2);

	         GroupLayout defaultTabLayout = new  GroupLayout(defaultTab);
	        defaultTab.setLayout(defaultTabLayout);
	        defaultTabLayout.setHorizontalGroup(
	            defaultTabLayout.createParallelGroup( GroupLayout.Alignment.LEADING)
	            .addComponent(jScrollPane2,  GroupLayout.DEFAULT_SIZE, 704, Short.MAX_VALUE)
	        );
	        defaultTabLayout.setVerticalGroup(
	            defaultTabLayout.createParallelGroup( GroupLayout.Alignment.LEADING)
	            .addComponent(jScrollPane2,  GroupLayout.DEFAULT_SIZE, 318, Short.MAX_VALUE)
	        );

	        connectionSubPanel.addTab("������", defaultTab);

	        jTable3.setFont(new java.awt.Font("���ʷҵ���", 0, 12)); // NOI18N
	        jTable3.setModel(new  DefaultTableModel(
	            new Object [][] {
	                {null, null, null, null},
	                {null, null, null, null},
	                {null, null, null, null},
	                {null, null, null, null}
	            },
	            new String [] {
	                "�̸�", "�̸���", "��ȭ��ȣ", "����"
	            }
	        ));
	        jScrollPane3.setViewportView(jTable3);

	         GroupLayout friendTabLayout = new  GroupLayout(friendTab);
	        friendTab.setLayout(friendTabLayout);
	        friendTabLayout.setHorizontalGroup(
	            friendTabLayout.createParallelGroup( GroupLayout.Alignment.LEADING)
	            .addComponent(jScrollPane3,  GroupLayout.DEFAULT_SIZE, 704, Short.MAX_VALUE)
	        );
	        friendTabLayout.setVerticalGroup(
	            friendTabLayout.createParallelGroup( GroupLayout.Alignment.LEADING)
	            .addComponent(jScrollPane3,  GroupLayout.Alignment.TRAILING,  GroupLayout.DEFAULT_SIZE, 318, Short.MAX_VALUE)
	        );

	        connectionSubPanel.addTab("ģ��", friendTab);

	        addButton.setFont(new java.awt.Font("���ʷҵ���", 0, 12)); // NOI18N
	        addButton.setText("�߰�");

	        modifyButton.setFont(new java.awt.Font("���ʷҵ���", 0, 12)); // NOI18N
	        modifyButton.setText("����");

	        deleteButton.setFont(new java.awt.Font("���ʷҵ���", 0, 12)); // NOI18N
	        deleteButton.setText("����");

	         GroupLayout layout = new  GroupLayout(this);
	        this.setLayout(layout);
	        layout.setHorizontalGroup(
	            layout.createParallelGroup( GroupLayout.Alignment.LEADING)
	            .addGroup(layout.createSequentialGroup()
	                .addGroup(layout.createParallelGroup( GroupLayout.Alignment.LEADING)
	                    .addGroup(layout.createSequentialGroup()
	                        .addGap(275, 275, 275)
	                        .addComponent(addButton)
	                        .addGap(18, 18, 18)
	                        .addComponent(modifyButton)
	                        .addGap(18, 18, 18)
	                        .addComponent(deleteButton))
	                    .addGroup(layout.createSequentialGroup()
	                        .addGap(20, 20, 20)
	                        .addComponent(connectionSubPanel,  GroupLayout.PREFERRED_SIZE, 713,  GroupLayout.PREFERRED_SIZE)))
	                .addContainerGap(23, Short.MAX_VALUE))
	        );
	        layout.setVerticalGroup(
	            layout.createParallelGroup( GroupLayout.Alignment.LEADING)
	            .addGroup(layout.createSequentialGroup()
	                .addGap(60, 60, 60)
	                .addComponent(connectionSubPanel,  GroupLayout.PREFERRED_SIZE, 353,  GroupLayout.PREFERRED_SIZE)
	                .addPreferredGap( LayoutStyle.ComponentPlacement.RELATED)
	                .addGroup(layout.createParallelGroup( GroupLayout.Alignment.BASELINE)
	                    .addComponent(addButton)
	                    .addComponent(modifyButton)
	                    .addComponent(deleteButton))
	                .addContainerGap(72, Short.MAX_VALUE))
	        );
	    }
	}
