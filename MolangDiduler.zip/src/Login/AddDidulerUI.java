package Login;
import  javax.swing.*;

public class AddDidulerUI extends  JFrame {

	    public AddDidulerUI() {
	        initComponents();
	    }

	    private void initComponents() {

	        buttonGroup1 = new  ButtonGroup();
	        jPanel1 = new  JPanel();
	        titleLable = new  JLabel();
	        titleTextfield = new  JTextField();
	        ContentScroll = new  JScrollPane();
	        content = new  JTextArea();
	        isPublicCombo = new  JComboBox();
	        isPublic = new  JLabel();
	        diaryButton = new  JRadioButton();
	        scheduleButton = new  JRadioButton();
	        diaryPanel = new  JPanel();
	        termLabel = new  JLabel();
	        startYearCombo = new  JComboBox();
	        startMonCombo = new  JComboBox();
	        startDayCombo = new  JComboBox();
	        termLabel2 = new  JLabel();
	        endYearCombo = new  JComboBox();
	        endMonCombo = new  JComboBox();
	        endDayCombo = new  JComboBox();
	        alarmCheck = new  JCheckBox();
	        pupupCombo = new  JComboBox();
	        popupLable = new  JLabel();
	        alarmbellLabel = new  JLabel();
	        alarmbellCombo = new  JComboBox();
	        checkButton = new  JButton();
	        cancelButton = new  JButton();
	        titleImage = new  JLabel();

	        setDefaultCloseOperation( WindowConstants.EXIT_ON_CLOSE);
	        setTitle("�����췯 �߰�");
	        setName("�����ٷ�"); // NOI18N
	        setResizable(false);

	        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
	        jPanel1.setName("�����ٷ��߰�"); // NOI18N
	        jPanel1.setPreferredSize(new java.awt.Dimension(400, 500));

	        titleLable.setFont(new java.awt.Font("���ʷҵ���", 0, 12)); // NOI18N
	        titleLable.setText("��  ��:");

	        titleTextfield.setFont(new java.awt.Font("���ʷҵ���", 0, 12)); // NOI18N
	        titleTextfield.addActionListener(new java.awt.event.ActionListener() {
	            public void actionPerformed(java.awt.event.ActionEvent evt) {
	                titleTextfieldActionPerformed(evt);
	            }
	        });

	        content.setColumns(20);
	        content.setFont(new java.awt.Font("���ʷҵ���", 0, 12)); // NOI18N
	        content.setRows(5);
	        ContentScroll.setViewportView(content);

	        isPublicCombo.setFont(new java.awt.Font("���ʷҵ���", 0, 12)); // NOI18N
	        isPublicCombo.setModel(new  DefaultComboBoxModel(new String[] { "��  ��", "�����" }));
	        isPublicCombo.addActionListener(new java.awt.event.ActionListener() {
	            public void actionPerformed(java.awt.event.ActionEvent evt) {
	                isPublicComboActionPerformed(evt);
	            }
	        });

	        isPublic.setFont(new java.awt.Font("���ʷҵ���", 0, 12)); // NOI18N
	        isPublic.setText("���� ���� :");

	        buttonGroup1.add(diaryButton);
	        diaryButton.setFont(new java.awt.Font("���ʷҵ���", 0, 12)); // NOI18N
	        diaryButton.setText("���̾");

	        buttonGroup1.add(scheduleButton);
	        scheduleButton.setFont(new java.awt.Font("���ʷҵ���", 0, 12)); // NOI18N
	        scheduleButton.setText("�� ��");
	        scheduleButton.addActionListener(new java.awt.event.ActionListener() {
	            public void actionPerformed(java.awt.event.ActionEvent evt) {
	                scheduleButtonActionPerformed(evt);
	            }
	        });

	        termLabel.setFont(new java.awt.Font("���ʷҵ���", 0, 12)); // NOI18N
	        termLabel.setText("�� �� :");

	        startYearCombo.setFont(new java.awt.Font("���ʷҵ���", 0, 12)); // NOI18N
	        startYearCombo.setModel(new  DefaultComboBoxModel(new String[] { "��", " " }));

	        startMonCombo.setFont(new java.awt.Font("���ʷҵ���", 0, 12)); // NOI18N
	        startMonCombo.setModel(new  DefaultComboBoxModel(new String[] { "��", " " }));

	        startDayCombo.setFont(new java.awt.Font("���ʷҵ���", 0, 12)); // NOI18N
	        startDayCombo.setModel(new  DefaultComboBoxModel(new String[] { "��" }));

	        termLabel2.setFont(new java.awt.Font("���ʷҵ���", 0, 12)); // NOI18N
	        termLabel2.setText("~");

	        endYearCombo.setFont(new java.awt.Font("���ʷҵ���", 0, 12)); // NOI18N
	        endYearCombo.setModel(new  DefaultComboBoxModel(new String[] { "��", " " }));

	        endMonCombo.setFont(new java.awt.Font("���ʷҵ���", 0, 12)); // NOI18N
	        endMonCombo.setModel(new  DefaultComboBoxModel(new String[] { "��", " " }));

	        endDayCombo.setFont(new java.awt.Font("���ʷҵ���", 0, 12)); // NOI18N
	        endDayCombo.setModel(new  DefaultComboBoxModel(new String[] { "��" }));

	        alarmCheck.setFont(new java.awt.Font("���ʷҵ���", 0, 12)); // NOI18N
	        alarmCheck.setText("��   ��");
	        alarmCheck.addActionListener(new java.awt.event.ActionListener() {
	            public void actionPerformed(java.awt.event.ActionEvent evt) {
	                alarmCheckActionPerformed(evt);
	            }
	        });

	        pupupCombo.setFont(new java.awt.Font("���ʷҵ���", 0, 12)); // NOI18N
	        pupupCombo.setModel(new  DefaultComboBoxModel(new String[] { "�� ��", "�� ��", " ", " " }));

	        popupLable.setFont(new java.awt.Font("���ʷҵ���", 0, 12)); // NOI18N
	        popupLable.setText("�� �� :");

	        alarmbellLabel.setFont(new java.awt.Font("���ʷҵ���", 0, 12)); // NOI18N
	        alarmbellLabel.setText("�� �� ��:");

	        alarmbellCombo.setFont(new java.awt.Font("���ʷҵ���", 0, 12)); // NOI18N
	        alarmbellCombo.setModel(new  DefaultComboBoxModel(new String[] { "�� ��", "�� ��" }));

	         GroupLayout diaryPanelLayout = new  GroupLayout(diaryPanel);
	        diaryPanel.setLayout(diaryPanelLayout);
	        diaryPanelLayout.setHorizontalGroup(
	            diaryPanelLayout.createParallelGroup( GroupLayout.Alignment.LEADING)
	            .addGroup(diaryPanelLayout.createSequentialGroup()
	                .addContainerGap()
	                .addGroup(diaryPanelLayout.createParallelGroup( GroupLayout.Alignment.LEADING)
	                    .addGroup(diaryPanelLayout.createSequentialGroup()
	                        .addComponent(alarmCheck)
	                        .addGap(18, 18, 18)
	                        .addComponent(popupLable)
	                        .addPreferredGap( LayoutStyle.ComponentPlacement.UNRELATED)
	                        .addComponent(pupupCombo,  GroupLayout.PREFERRED_SIZE, 61,  GroupLayout.PREFERRED_SIZE)
	                        .addPreferredGap( LayoutStyle.ComponentPlacement.RELATED)
	                        .addComponent(alarmbellLabel,  GroupLayout.PREFERRED_SIZE, 56,  GroupLayout.PREFERRED_SIZE)
	                        .addPreferredGap( LayoutStyle.ComponentPlacement.UNRELATED)
	                        .addComponent(alarmbellCombo,  GroupLayout.PREFERRED_SIZE,  GroupLayout.DEFAULT_SIZE,  GroupLayout.PREFERRED_SIZE)
	                        .addGap(0, 0, Short.MAX_VALUE))
	                    .addGroup(diaryPanelLayout.createSequentialGroup()
	                        .addComponent(termLabel,  GroupLayout.PREFERRED_SIZE, 39,  GroupLayout.PREFERRED_SIZE)
	                        .addPreferredGap( LayoutStyle.ComponentPlacement.RELATED)
	                        .addComponent(startYearCombo,  GroupLayout.PREFERRED_SIZE, 56,  GroupLayout.PREFERRED_SIZE)
	                        .addGap(5, 5, 5)
	                        .addComponent(startMonCombo,  GroupLayout.PREFERRED_SIZE,  GroupLayout.DEFAULT_SIZE,  GroupLayout.PREFERRED_SIZE)
	                        .addGap(5, 5, 5)
	                        .addComponent(startDayCombo,  GroupLayout.PREFERRED_SIZE,  GroupLayout.DEFAULT_SIZE,  GroupLayout.PREFERRED_SIZE)
	                        .addPreferredGap( LayoutStyle.ComponentPlacement.RELATED)
	                        .addComponent(termLabel2,  GroupLayout.PREFERRED_SIZE, 16,  GroupLayout.PREFERRED_SIZE)
	                        .addPreferredGap( LayoutStyle.ComponentPlacement.RELATED)
	                        .addComponent(endYearCombo, 0,  GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
	                        .addPreferredGap( LayoutStyle.ComponentPlacement.RELATED)
	                        .addComponent(endMonCombo,  GroupLayout.PREFERRED_SIZE,  GroupLayout.DEFAULT_SIZE,  GroupLayout.PREFERRED_SIZE)
	                        .addPreferredGap( LayoutStyle.ComponentPlacement.RELATED)
	                        .addComponent(endDayCombo,  GroupLayout.PREFERRED_SIZE,  GroupLayout.DEFAULT_SIZE,  GroupLayout.PREFERRED_SIZE)))
	                .addContainerGap())
	        );
	        diaryPanelLayout.setVerticalGroup(
	            diaryPanelLayout.createParallelGroup( GroupLayout.Alignment.LEADING)
	            .addGroup(diaryPanelLayout.createSequentialGroup()
	                .addContainerGap()
	                .addGroup(diaryPanelLayout.createParallelGroup( GroupLayout.Alignment.BASELINE)
	                    .addComponent(termLabel,  GroupLayout.PREFERRED_SIZE, 23,  GroupLayout.PREFERRED_SIZE)
	                    .addComponent(startYearCombo,  GroupLayout.PREFERRED_SIZE,  GroupLayout.DEFAULT_SIZE,  GroupLayout.PREFERRED_SIZE)
	                    .addComponent(endYearCombo,  GroupLayout.PREFERRED_SIZE,  GroupLayout.DEFAULT_SIZE,  GroupLayout.PREFERRED_SIZE)
	                    .addComponent(endMonCombo,  GroupLayout.PREFERRED_SIZE,  GroupLayout.DEFAULT_SIZE,  GroupLayout.PREFERRED_SIZE)
	                    .addComponent(endDayCombo,  GroupLayout.PREFERRED_SIZE,  GroupLayout.DEFAULT_SIZE,  GroupLayout.PREFERRED_SIZE)
	                    .addComponent(termLabel2)
	                    .addComponent(startDayCombo,  GroupLayout.PREFERRED_SIZE,  GroupLayout.DEFAULT_SIZE,  GroupLayout.PREFERRED_SIZE)
	                    .addComponent(startMonCombo,  GroupLayout.PREFERRED_SIZE,  GroupLayout.DEFAULT_SIZE,  GroupLayout.PREFERRED_SIZE))
	                .addGap(18, 18, 18)
	                .addGroup(diaryPanelLayout.createParallelGroup( GroupLayout.Alignment.LEADING)
	                    .addGroup(diaryPanelLayout.createParallelGroup( GroupLayout.Alignment.BASELINE)
	                        .addComponent(alarmbellCombo,  GroupLayout.PREFERRED_SIZE,  GroupLayout.DEFAULT_SIZE,  GroupLayout.PREFERRED_SIZE)
	                        .addComponent(alarmbellLabel))
	                    .addGroup(diaryPanelLayout.createParallelGroup( GroupLayout.Alignment.BASELINE)
	                        .addComponent(alarmCheck)
	                        .addComponent(pupupCombo,  GroupLayout.PREFERRED_SIZE,  GroupLayout.DEFAULT_SIZE,  GroupLayout.PREFERRED_SIZE)
	                        .addComponent(popupLable)))
	                .addContainerGap(20, Short.MAX_VALUE))
	        );

	        checkButton.setFont(new java.awt.Font("���ʷҵ���", 0, 12)); // NOI18N
	        checkButton.setText("Ȯ ��");
	        checkButton.addActionListener(new java.awt.event.ActionListener() {
	            public void actionPerformed(java.awt.event.ActionEvent evt) {
	                checkButtonActionPerformed(evt);
	            }
	        });

	        cancelButton.setFont(new java.awt.Font("���ʷҵ���", 0, 12)); // NOI18N
	        cancelButton.setText("�� ��");
	        cancelButton.addActionListener(new java.awt.event.ActionListener() {
	            public void actionPerformed(java.awt.event.ActionEvent evt) {
	                cancelButtonActionPerformed(evt);
	            }
	        });

	        titleImage.setIcon(new  ImageIcon("�׸�4.png")); // NOI18N

	         GroupLayout jPanel1Layout = new  GroupLayout(jPanel1);
	        jPanel1.setLayout(jPanel1Layout);
	        jPanel1Layout.setHorizontalGroup(
	            jPanel1Layout.createParallelGroup( GroupLayout.Alignment.LEADING)
	            .addGroup(jPanel1Layout.createSequentialGroup()
	                .addGap(126, 126, 126)
	                .addComponent(checkButton)
	                .addGap(18, 18, 18)
	                .addComponent(cancelButton)
	                .addContainerGap( GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
	            .addGroup(jPanel1Layout.createSequentialGroup()
	                .addGroup(jPanel1Layout.createParallelGroup( GroupLayout.Alignment.LEADING)
	                    .addGroup( GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
	                        .addGap(24, 24, 24)
	                        .addComponent(isPublic)
	                        .addPreferredGap( LayoutStyle.ComponentPlacement.RELATED)
	                        .addComponent(isPublicCombo,  GroupLayout.PREFERRED_SIZE,  GroupLayout.DEFAULT_SIZE,  GroupLayout.PREFERRED_SIZE)
	                        .addGap(32, 32, 32)
	                        .addComponent(scheduleButton,  GroupLayout.PREFERRED_SIZE, 63,  GroupLayout.PREFERRED_SIZE)
	                        .addPreferredGap( LayoutStyle.ComponentPlacement.UNRELATED)
	                        .addComponent(diaryButton,  GroupLayout.DEFAULT_SIZE,  GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
	                    .addGroup(jPanel1Layout.createSequentialGroup()
	                        .addContainerGap()
	                        .addComponent(diaryPanel,  GroupLayout.DEFAULT_SIZE,  GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
	                    .addGroup(jPanel1Layout.createSequentialGroup()
	                        .addContainerGap()
	                        .addGroup(jPanel1Layout.createParallelGroup( GroupLayout.Alignment.LEADING)
	                            .addComponent(ContentScroll)
	                            .addGroup(jPanel1Layout.createSequentialGroup()
	                                .addGap(0, 0, Short.MAX_VALUE)
	                                .addComponent(titleImage)
	                                .addPreferredGap( LayoutStyle.ComponentPlacement.RELATED)
	                                .addComponent(titleLable,  GroupLayout.PREFERRED_SIZE, 45,  GroupLayout.PREFERRED_SIZE)
	                                .addPreferredGap( LayoutStyle.ComponentPlacement.RELATED)
	                                .addComponent(titleTextfield,  GroupLayout.PREFERRED_SIZE, 284,  GroupLayout.PREFERRED_SIZE)))))
	                .addContainerGap())
	        );
	        jPanel1Layout.setVerticalGroup(
	            jPanel1Layout.createParallelGroup( GroupLayout.Alignment.LEADING)
	            .addGroup(jPanel1Layout.createSequentialGroup()
	                .addGroup(jPanel1Layout.createParallelGroup( GroupLayout.Alignment.LEADING)
	                    .addGroup(jPanel1Layout.createSequentialGroup()
	                        .addGap(31, 31, 31)
	                        .addGroup(jPanel1Layout.createParallelGroup( GroupLayout.Alignment.BASELINE)
	                            .addComponent(titleTextfield,  GroupLayout.PREFERRED_SIZE, 26,  GroupLayout.PREFERRED_SIZE)
	                            .addComponent(titleLable,  GroupLayout.PREFERRED_SIZE, 26,  GroupLayout.PREFERRED_SIZE)))
	                    .addGroup(jPanel1Layout.createSequentialGroup()
	                        .addContainerGap()
	                        .addComponent(titleImage)))
	                .addPreferredGap( LayoutStyle.ComponentPlacement.UNRELATED, 33, Short.MAX_VALUE)
	                .addComponent(ContentScroll,  GroupLayout.PREFERRED_SIZE, 304,  GroupLayout.PREFERRED_SIZE)
	                .addPreferredGap( LayoutStyle.ComponentPlacement.RELATED)
	                .addGroup(jPanel1Layout.createParallelGroup( GroupLayout.Alignment.BASELINE)
	                    .addComponent(isPublic,  GroupLayout.PREFERRED_SIZE, 23,  GroupLayout.PREFERRED_SIZE)
	                    .addComponent(isPublicCombo,  GroupLayout.PREFERRED_SIZE,  GroupLayout.DEFAULT_SIZE,  GroupLayout.PREFERRED_SIZE)
	                    .addComponent(scheduleButton)
	                    .addComponent(diaryButton))
	                .addGap(16, 16, 16)
	                .addComponent(diaryPanel,  GroupLayout.PREFERRED_SIZE,  GroupLayout.DEFAULT_SIZE,  GroupLayout.PREFERRED_SIZE)
	                .addPreferredGap( LayoutStyle.ComponentPlacement.RELATED)
	                .addGroup(jPanel1Layout.createParallelGroup( GroupLayout.Alignment.BASELINE)
	                    .addComponent(checkButton,  GroupLayout.DEFAULT_SIZE,  GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
	                    .addComponent(cancelButton,  GroupLayout.DEFAULT_SIZE,  GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
	                .addGap(7, 7, 7))
	        );

	         GroupLayout layout = new  GroupLayout(getContentPane());
	        getContentPane().setLayout(layout);
	        layout.setHorizontalGroup(
	            layout.createParallelGroup( GroupLayout.Alignment.LEADING)
	            .addGroup(layout.createSequentialGroup()
	                .addComponent(jPanel1,  GroupLayout.PREFERRED_SIZE, 415,  GroupLayout.PREFERRED_SIZE)
	                .addGap(0, 0, Short.MAX_VALUE))
	        );
	        layout.setVerticalGroup(
	            layout.createParallelGroup( GroupLayout.Alignment.LEADING)
	            .addGroup(layout.createSequentialGroup()
	                .addComponent(jPanel1,  GroupLayout.DEFAULT_SIZE, 586, Short.MAX_VALUE)
	                .addContainerGap())
	        );

	        pack();
	    }// </editor-fold>

	    private void cancelButtonActionPerformed(java.awt.event.ActionEvent evt) {                                             
	        // TODO add your handling code here:
	    }                                            

	    private void checkButtonActionPerformed(java.awt.event.ActionEvent evt) {                                            
	        // TODO add your handling code here:
	    }                                           

	    private void alarmCheckActionPerformed(java.awt.event.ActionEvent evt) {                                           
	        // TODO add your handling code here:
	    }                                          

	    private void scheduleButtonActionPerformed(java.awt.event.ActionEvent evt) {                                               
	        // TODO add your handling code here:
	         
	    }                                              

	    private void isPublicComboActionPerformed(java.awt.event.ActionEvent evt) {                                              
	        // TODO add your handling code here:
	    }                                             

	    private void titleTextfieldActionPerformed(java.awt.event.ActionEvent evt) {                                               
	        // TODO add your handling code here:
	    }                                              

	    /**
	     * @param args the command line arguments
	     */
	    public static void main(String args[]) {
	        /* Set the Nimbus look and feel */
	        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
	        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
	         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
	         */
	        try {
	            for ( UIManager.LookAndFeelInfo info :  UIManager.getInstalledLookAndFeels()) {
	                if ("Nimbus".equals(info.getName())) {
	                     UIManager.setLookAndFeel(info.getClassName());
	                    break;
	                }
	            }
	        } catch (ClassNotFoundException ex) {
	            java.util.logging.Logger.getLogger(AddDidulerUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
	        } catch (InstantiationException ex) {
	            java.util.logging.Logger.getLogger(AddDidulerUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
	        } catch (IllegalAccessException ex) {
	            java.util.logging.Logger.getLogger(AddDidulerUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
	        } catch ( UnsupportedLookAndFeelException ex) {
	            java.util.logging.Logger.getLogger(AddDidulerUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
	        }
	        //</editor-fold>

	        /* Create and display the form */
	        java.awt.EventQueue.invokeLater(new Runnable() {
	            public void run() {
	                new AddDidulerUI().setVisible(true);
	            }
	        });
	    }

	    private  JScrollPane ContentScroll;
	    private  JCheckBox alarmCheck;
	    private  JComboBox alarmbellCombo;
	    private  JLabel alarmbellLabel;
	    private  ButtonGroup buttonGroup1;
	    private  JButton cancelButton;
	    private  JButton checkButton;
	    private  JTextArea content;
	    private  JRadioButton diaryButton;
	    private  JPanel diaryPanel;
	    private  JComboBox endDayCombo;
	    private  JComboBox endMonCombo;
	    private  JComboBox endYearCombo;
	    private  JLabel isPublic;
	    private  JComboBox isPublicCombo;
	    private  JPanel jPanel1;
	    private  JLabel popupLable;
	    private  JComboBox pupupCombo;
	    private  JRadioButton scheduleButton;
	    private  JComboBox startDayCombo;
	    private  JComboBox startMonCombo;
	    private  JComboBox startYearCombo;
	    private  JLabel termLabel;
	    private  JLabel termLabel2;
	    private  JLabel titleImage;
	    private  JLabel titleLable;
	    private  JTextField titleTextfield;

	}
