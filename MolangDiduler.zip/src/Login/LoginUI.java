package Login;
import  javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class LoginUI extends  JFrame {
	
	private  JButton cancelButton;
    private  JTextField idField;
    private  JLabel jLabel1;
    private  JLabel jLabel2;
    private  JLabel jLabel3;
    private  JLabel jLabel4;
    private  JPanel jPanel1;
    private  JButton loginButton;
    private  JPasswordField passwordField;
   
    public LoginUI() {
        initComponents();
    }

    private void initComponents() {

        jPanel1 = new  JPanel();
        jLabel1 = new  JLabel();
        jLabel2 = new  JLabel();
        jLabel3 = new  JLabel();
        jLabel4 = new  JLabel();
        idField = new  JTextField();
        passwordField = new  JPasswordField();
        loginButton = new  JButton();
        cancelButton = new  JButton();

        setDefaultCloseOperation( WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 255));
        setPreferredSize(new java.awt.Dimension(520, 370));
        setLocation(500,300);
        getContentPane().setLayout(null);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(null);

        jLabel1.setFont(new java.awt.Font("���ʷҵ���", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 51, 255));
        jLabel1.setText("Molang Diduler");
        jPanel1.add(jLabel1);
        jLabel1.setBounds(20, 140, 180, 30);

        
        jLabel2.setIcon(new  ImageIcon("011.png")); // NOI18N
        jLabel2.setText("����");
        jPanel1.add(jLabel2);
        jLabel2.setBounds(230, 20, 240, 170);

        jLabel3.setFont(new java.awt.Font("���ʷҵ���", 1, 14)); // NOI18N
        jLabel3.setText("ID");
        jPanel1.add(jLabel3);
        jLabel3.setBounds(120, 220, 20, 19);

        jLabel4.setFont(new java.awt.Font("���ʷҵ���", 1, 14)); // NOI18N
        jLabel4.setText("Password");
        jPanel1.add(jLabel4);
        jLabel4.setBounds(70, 260, 70, 20);
        jPanel1.add(idField);
        idField.setBounds(180, 220, 110, 21);
        jPanel1.add(passwordField);
        passwordField.setBounds(180, 260, 110, 21);

        loginButton.setFont(new java.awt.Font("���ʷҵ���", 0, 12)); // NOI18N
        loginButton.setText("�α���");
        jPanel1.add(loginButton);
        loginButton.setBounds(300, 290, 80, 25);

        cancelButton.setFont(new java.awt.Font("���ʷҵ���", 0, 12)); // NOI18N
        cancelButton.setText("���");
        jPanel1.add(cancelButton);
        cancelButton.setBounds(400, 290, 80, 25);
        cancelButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
        getContentPane().add(jPanel1);
        jPanel1.setBounds(0, 0, 500, 330);

        pack();
    }

    public static void main(String args[]) {
    	new LoginUI().setVisible(true);

    }

    
    
    
}
